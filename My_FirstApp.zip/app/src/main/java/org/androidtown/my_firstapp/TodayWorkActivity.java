package org.androidtown.my_firstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class TodayWorkActivity extends AppCompatActivity {
    static final String[] LIST_MENU = {"LIST1","LIST2","LIST3"};
    ListView listview;
    ArrayAdapter adapter;
    EditText input;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_work);

        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice,LIST_MENU);
        listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        input = findViewById(R.id.editText3);
    }

    public void onAddButtonClicked(View v){
        String text;
        text = (String) input.getText().toString();
        listview.
    }

}
